# Design System Specification: High-End Editorial Tech

## 1. Overview & Creative North Star: "The Architectural Ledger"
This design system moves beyond the generic "SaaS dashboard" look to create a high-end, editorial experience tailored for the modern developer. The Creative North Star is **"The Architectural Ledger"**—a concept that treats the UI as a structured, technical document where information is organized through spatial depth and tonal shifts rather than rigid lines.

By utilizing intentional asymmetry, extreme typographic contrast, and a "layered paper" philosophy, we break the "template" feel. We replace standard borders with sophisticated tonal stacking, ensuring the AKL Tech experience feels premium, custom-made, and developer-centric.

---

## 2. Colors & Tonal Surface Logic
We utilize a sophisticated Material-based palette to manage light and dark modes with high precision.

### The Palette
*   **Primary (`#0056c5` / `#0f6df3`):** Our "Electric Blue" core. Used for momentum and high-priority actions.
*   **Background (`#f9f9ff`):** A crisp, cool-white base that provides a technical, sterile-yet-inviting canvas.
*   **Surface Tiers:**
    *   `surface_container_lowest`: `#ffffff` (Floating cards/Active elements)
    *   `surface_container_low`: `#f0f3ff` (Section backgrounds)
    *   `surface_container_highest`: `#d7e3fc` (Deep-set UI elements/Inactive states)

### The "No-Line" Rule
**Explicit Instruction:** Do not use 1px solid borders to section content. Boundaries must be defined solely through background color shifts. For example, a `surface_container_low` section sitting on a `surface` background creates a clear, sophisticated boundary without the visual "noise" of a stroke.

### Surface Hierarchy & Nesting
Treat the UI as physical layers. An event card (`surface_container_lowest`) should sit atop a category section (`surface_container_low`), which sits on the global `background`. This "Nesting" creates natural depth and directs the eye to the most important data points.

### The "Glass & Gradient" Rule
To elevate hero sections or navigation bars, use **Glassmorphism**. Apply `surface` colors at 70% opacity with a 20px backdrop-blur. For primary CTAs, use a subtle linear gradient from `primary` to `primary_container` (top-left to bottom-right) to add "visual soul" and a metallic, premium sheen.

---

## 3. Typography: Technical Authority
We pair the geometric precision of **Space Grotesk** with the utilitarian clarity of **Inter**.

*   **Display & Headlines (Space Grotesk):** High-contrast, wide-tracking headers. Use `display-lg` (3.5rem) for hero event titles to create an editorial, "poster" feel.
*   **Body & Labels (Inter):** Used for all technical data and descriptions. The clean sans-serif nature of Inter ensures legibility in dense developer-focused schedules.
*   **Hierarchy Tip:** Always skip a size in the scale for emphasis (e.g., pair a `headline-sm` with a `body-sm`) to create the dramatic "editorial" tension that defines this system.

---

## 4. Elevation & Depth
Depth in this system is achieved through **Tonal Layering**, not structural lines.

*   **The Layering Principle:** Stack `surface-container` tiers. A `surface_container_lowest` card placed on a `surface_container_high` background provides an immediate, soft lift.
*   **Ambient Shadows:** For floating elements (Modals/Dropdowns), use "Atmospheric Shadows." Shadows must be extra-diffused: `box-shadow: 0 12px 40px rgba(16, 28, 46, 0.06)`. The shadow color is a tint of our `on_surface` navy, never pure black.
*   **The "Ghost Border" Fallback:** If a border is required for accessibility (e.g., Input fields), use the `outline_variant` at 20% opacity. 100% opaque borders are strictly forbidden.

---

## 5. Components

### Buttons
*   **Primary:** Gradient fill (`primary` to `primary_container`), `DEFAULT` (0.5rem) rounded corners. Text is `label-md` uppercase with 0.05em letter spacing.
*   **Secondary:** `surface_container_low` fill with `primary` text. No border.
*   **Interaction:** On hover, primary buttons should "lift" with an Ambient Shadow; secondary buttons shift to `surface_container_high`.

### Cards (Events/Sessions)
*   **Construction:** Use `surface_container_lowest` background. 
*   **Spacing:** Use `6` (1.5rem) internal padding. 
*   **Rule:** Forbid divider lines within cards. Use `spacing-4` (1rem) vertical white space or a subtle `surface_variant` background toggle to separate the "Date" from the "Event Title."

### Chips (Tech Tags)
*   **Visuals:** `md` (0.75rem) roundedness. Use `secondary_container` backgrounds with `on_secondary_container` text. This provides a "technical badge" aesthetic that feels developer-friendly.

### Input Fields
*   **Style:** Minimalist. Use `surface_container_low` as the background. On focus, transition the background to `surface_container_lowest` and apply a 1px "Ghost Border" using `primary`.

### Navigation (The Glass Rail)
*   For the main header, use a transparent `surface` with a heavy backdrop-blur. This allows event imagery to bleed through as the user scrolls, creating a sense of immersion.

---

## 6. Do’s and Don’ts

### Do:
*   **Do** use asymmetrical spacing (e.g., more padding on the left than the right in hero sections) to create a custom, high-end feel.
*   **Do** lean into white space. If a layout feels crowded, increase spacing using the `spacing-12` or `spacing-16` tokens.
*   **Do** use `tertiary` (Burnt Orange/Brown) sparingly as a "technical highlight" for things like "Live Now" or "Code Snippet" labels.

### Don't:
*   **Don't** use 1px solid black or grey borders. This immediately reverts the design to a "generic" state.
*   **Don't** use standard "drop shadows." If the shadow doesn't look like ambient light, it is too heavy.
*   **Don't** use Inter for large headlines. Space Grotesk is our brand’s voice; Inter is its technical manual.